BOOTSTRAP = (
    "https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/"
    "font/bootstrap-icons.css"
)
FONT_AWESOME = "https://use.fontawesome.com/releases/v6.1.1/css/all.css"
